# CepAsistan AI sunucusu (Cloudflare Worker)

Uygulamadaki `AI_ENDPOINT` (`.../chat`) ve notlar için `.../note` uç noktalarını sunar.
API anahtarı yalnızca burada, secret olarak durur; uygulamaya gömülmez.

## Kurulum (bir kez)
```bash
cd worker
npm install -g wrangler          # ya da: npx wrangler ...
wrangler login
wrangler kv namespace create QUOTA   # çıkan id'yi wrangler.toml içine yaz
wrangler secret put AI_API_KEY       # Anthropic veya OpenAI anahtarı
wrangler deploy
```
Sağlayıcı/model değiştirmek için `wrangler.toml` içindeki `AI_PROVIDER` ve `AI_MODEL` değerlerini düzenle:
- Claude: `AI_PROVIDER="anthropic"`, `AI_MODEL="claude-haiku-5-5"`
- OpenAI: `AI_PROVIDER="openai"`, `AI_MODEL="<OpenAI model adı>"`

## Test
`node test.mjs` (sahte KV ve sahte API ile kota, hata ve JSON ayrıştırmayı dener)

## Bilinen sınırlar
- Kota KV'de tutulur; KV yazmaları atomik değildir, aynı anda gelen çok sayıda istek 1-2 fazladan hakka yol açabilir. Küçük ölçekte sorun değil.
- İstemci kimliği cihazda üretilir; uygulama silinip kurulunca yeni hak verir. IP başına toplam sınır (`IP_LIMIT`) bunu sınırlar.
- Pro (ücretli) kullanıcı ayrımı henüz yok: herkes `FREE_LIMIT` ile çalışır. Pro için Google Play makbuz doğrulaması eklenmeli.
